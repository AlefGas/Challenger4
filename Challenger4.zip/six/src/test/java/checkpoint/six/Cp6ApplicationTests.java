package checkpoint.six;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Cp6ApplicationTests {

	@Test
	void contextLoads() {
	}

}
