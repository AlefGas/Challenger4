package checkpoint.six.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import checkpoint.six.model.Veiculo;

public interface VeiculoRepository extends JpaRepository<Veiculo, String> {

}
