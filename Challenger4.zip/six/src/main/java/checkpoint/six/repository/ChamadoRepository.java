package checkpoint.six.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import checkpoint.six.model.Chamado;


@Repository
public interface ChamadoRepository  extends JpaRepository<Chamado, Long> {
	

}
