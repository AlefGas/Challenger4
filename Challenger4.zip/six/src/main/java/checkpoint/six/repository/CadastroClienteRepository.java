package checkpoint.six.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import checkpoint.six.model.CadastroCliente;

public interface CadastroClienteRepository extends JpaRepository< CadastroCliente, String> {

	List<CadastroCliente> findAll();

}
