package checkpoint.six.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import checkpoint.six.model.Guincho;


@Repository
public interface GuinchoRepository extends JpaRepository<Guincho, String> {

	

	Optional<Guincho> findById(String Id);
}

