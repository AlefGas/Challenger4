package checkpoint.six.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import checkpoint.six.model.Chamado;
import checkpoint.six.model.Cliente;
import checkpoint.six.model.Guincho;

import checkpoint.six.repository.GuinchoRepository;
import service.GuinchoService;
@RestController
@RequestMapping("/guincho")
public class GuinchoController {
	@Autowired
	private GuinchoService guinchoService;
		    
		    

		    @GetMapping
		    public List<Guincho> listar() {
		        try {
		        	return guinchoService.listarTodosGuinchos();
		        } catch (Exception e) {

		            return (List<Guincho>) ResponseEntity.internalServerError().build();
		        }
		    }
		    @GetMapping("/guinchoporid/{id}")
		    public Optional<Guincho> listaguinchoporid(@PathVariable(value="id")String Id) {
		    	return guinchoService.encontrarGuinchoPorId(Id);
		        
		    }

		    @PostMapping
		    public Guincho adicionar(@RequestBody Guincho guincho) {
		        try {
		        	return guinchoService.adicionarGuincho(guincho);
		        } catch (Exception e) {
		            System.err.println(e);
		            return null;
		        }
		    }
		    @DeleteMapping
		    public void deleta(@RequestBody Guincho guincho) {
		        try {
		        guinchoService.deletarGuincho(guincho);
		           System.out.println("foi deletado com exito");
		        } catch (Exception e) {
		            System.err.println(e);
		            return;
		        }
		    }
		    
		    @PutMapping
		    public Guincho atualizaGuincho(@RequestBody Guincho guincho) {
		        try {
		        	return guinchoService.atualizarGuincho(guincho);
		        } catch (Exception e) {
		            System.err.println(e);
		            return null;
		        }
		    }

	}

