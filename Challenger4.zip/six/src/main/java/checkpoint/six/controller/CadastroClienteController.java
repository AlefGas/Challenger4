package checkpoint.six.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

import checkpoint.six.model.CadastroCliente;
import checkpoint.six.repository.CadastroClienteRepository;
import checkpoint.six.repository.ClienteRepository;

public class CadastroClienteController {
	  @Autowired
	  private CadastroClienteRepository cadastroClienteRepository;

	    @GetMapping
	    public List<CadastroCliente> listar() {
	        try {
	            return cadastroClienteRepository.findAll();
	        } catch (Exception e) {

	            return (List<CadastroCliente>) ResponseEntity.internalServerError().build();
	        }
	    }
	    @GetMapping("/clienteporid/{id}")
	    public Optional<CadastroCliente> listaclienteporid(@PathVariable(value="id")String Id) {
	       return cadastroClienteRepository.findById(Id);
	        
	    }

	    @PostMapping
	    public CadastroCliente adicionar(@RequestBody CadastroCliente cadastrocliente) {
	        try {
	            return cadastroClienteRepository.save(cadastrocliente);
	        } catch (Exception e) {
	            System.err.println(e);
	            return null;
	        }
	    }
	    @DeleteMapping
	    public void deletacadastro(@RequestBody CadastroCliente cadastrocliente) {
	        try {
	           cadastroClienteRepository.delete(cadastrocliente);
	        } catch (Exception e) {
	            System.err.println(e);
	            return;
	        }
	    }
	    
	    @PutMapping
	    public CadastroCliente atualizaCadastroCliente(@RequestBody CadastroCliente cadastrocliente) {
	        try {
	            return cadastroClienteRepository.save(cadastrocliente);
	        } catch (Exception e) {
	            System.err.println(e);
	            return null;
	        }
	    }

}
