package checkpoint.six.controller;

import checkpoint.six.model.Cliente;

import checkpoint.six.repository.ClienteRepository;
import service.ClienteServiceImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/clientes")
public class ClienteController {
    @Autowired
    private ClienteRepository clienteRepository;
    private ClienteServiceImpl clienteService;
    @GetMapping
    public List<Cliente> listar() {
        try {
            return clienteService.listarTodosClientes();
        } catch (Exception e) {

            return (List<Cliente>) ResponseEntity.internalServerError().build();
        }
    }
    @GetMapping("/clienteporid/{id}")
    public Optional<Cliente> listaclienteporid(@PathVariable(value="id")Long Id) {
       return clienteService.encontrarClientePorId(Id);
        
    }

    @PostMapping
    public Cliente adicionar(@RequestBody Cliente cliente) {
        try {
            return clienteService.adicionarCliente(cliente);
        } catch (Exception e) {
            System.err.println(e);
            return null;
        }
    }
    @DeleteMapping
    public void deleta( Cliente cliente) {
        try {
        	clienteService.deletarCliente(cliente);
           System.out.println("foi deletado com exito");
        } catch (Exception e) {
            System.err.println(e);
            return;
        }
    }
    
    @PutMapping
    public Cliente atualizaCliente(@RequestBody Cliente cliente) {
        try {
            return clienteService.atualizarCliente(cliente);
        } catch (Exception e) {
            System.err.println(e);
            return null;
        }
    }
}
