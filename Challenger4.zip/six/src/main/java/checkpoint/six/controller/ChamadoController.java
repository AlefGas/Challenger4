package checkpoint.six.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import checkpoint.six.model.Chamado;
import checkpoint.six.repository.ChamadoRepository;
import service.ChamadoService;



@RestController
@RequestMapping("/chamado")
public class ChamadoController {
		@Autowired
		private ChamadoService chamadoService;
		
	    @Autowired
	    private ChamadoRepository chamadoRepository;

	    @GetMapping
	    public List<Chamado> listar() {
	        try {
	            return chamadoService.listarTodosChamados();
	        } catch (Exception e) {

	            return (List<Chamado>) ResponseEntity.internalServerError().build();
	        }
	    }
	    @GetMapping("/chamadoporid/{id}")
	    public Optional<Chamado> listachamadoporid(@PathVariable(value="id")Long Id) {
	       return chamadoService.encontrarChamadoPorId(Id);
	        
	    }

	    @PostMapping
	    public Chamado adicionar(@RequestBody Chamado chamado) {
	        try {
	            return chamadoService.adicionarChamado(chamado);
	        } catch (Exception e) {
	            System.err.println(e);
	            return null;
	        }
	    }
	    @DeleteMapping
	    public void deleta(@RequestBody Chamado chamado) {
	        try {
	           chamadoService.deletarChamado(chamado);
	           System.out.println("foi deletado com exito");
	        } catch (Exception e) {
	            System.err.println(e);
	            
	        }
	    }
	    @PutMapping
	    public Chamado atualizaChamado(@RequestBody Chamado chamado) {
	        try {
	            return chamadoService.atualizarChamado(chamado);
	        } catch (Exception e) {
	            System.err.println(e);
	            return null;
	        }
	    }
	    

}
