package checkpoint.six.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import checkpoint.six.model.Chamado;
import checkpoint.six.model.Cliente;
import checkpoint.six.model.Guincho;
import checkpoint.six.model.Veiculo;
import checkpoint.six.repository.VeiculoRepository;
import service.VeiculoService;

@RestController
@RequestMapping("/veiculo")
public class VeiculoController {
	@Autowired
	private VeiculoService veiculoService;
	
	@GetMapping
	public List<Veiculo> listar(){
		try {
			return veiculoService.listarTodosVeiculos();
        } catch (Exception e) {

            return (List<Veiculo>) ResponseEntity.internalServerError().build();
        }
    
	}
	@GetMapping("/veiculoporid/{id}")
    public Optional<Veiculo> listaveiculoporid(@PathVariable(value="id")String Id) {
       return veiculoService.encontrarVeiculoPorId(Id);
        
    }
	@PostMapping
    public Veiculo adicionar(@RequestBody Veiculo veiculo) {
        try {
        	return veiculoService.adicionarVeiculo(veiculo);
        } catch (Exception e) {
            System.err.println(e);
            return null;
        }
	}
        
     @DeleteMapping
	 public void deleta(@RequestBody Veiculo veiculo) {
	        try {
	        	veiculoService.deletarVeiculo(veiculo);
	        } catch (Exception e) {
	            System.err.println(e);
	            return;
	        }
     
	}
     
     @PutMapping
	    public Veiculo atualizaChamado(@RequestBody Veiculo veiculo) {
	        try {
	        	return veiculoService.atualizarVeiculo(veiculo);
	        } catch (Exception e) {
	            System.err.println(e);
	            return null;
	        }
	    }
}
