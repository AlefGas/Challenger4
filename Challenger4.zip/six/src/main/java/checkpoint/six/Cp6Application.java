package checkpoint.six;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;


@SpringBootApplication
@ComponentScan(basePackages = {"checkpoint.six.controller", "service"})
public class Cp6Application {
	
	public static void main(String[] args) {
		SpringApplication.run(Cp6Application.class, args);
	}

}
