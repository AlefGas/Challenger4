package checkpoint.six.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Guincho {
	
	@Id
	private String placa;
	private String localidade;
	private long potenciakg;
	private String tipo;
	public String getPlaca() {
		return placa;
	}
	public void setPlaca(String placa) {
		this.placa = placa;
	}
	public String getLocalidade() {
		return localidade;
	}
	public void setLocalidade(String localidade) {
		this.localidade = localidade;
	}
	public long getPotenciakg() {
		return potenciakg;
	}
	public void setPotenciakg(long potenciakg) {
		this.potenciakg = potenciakg;
	}
	public String getTipo() {
		return tipo;
	}
	public void setTipo(String tipo) {
		this.tipo = tipo;
	}
	
	
}
