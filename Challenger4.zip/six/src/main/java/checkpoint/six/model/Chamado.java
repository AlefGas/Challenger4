package checkpoint.six.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;


@Entity
public class Chamado {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long IdChamado;
	private String Causa;
	private String NomeCliente;
	
	//getters setters
	public Long getIdChamado() {
		return IdChamado;
	}
	public void setIdChamado(Long idChamado) {
		IdChamado = idChamado;
	}
	public String getCausa() {
		return Causa;
	}
	public void setCausa(String causa) {
		Causa = causa;
	}
	public String getNomeCliente() {
		return NomeCliente;
	}
	public void setNomeCliente(String nomeCliente) {
		NomeCliente = nomeCliente;
	}
	
	

}
