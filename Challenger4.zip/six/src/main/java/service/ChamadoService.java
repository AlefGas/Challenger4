package service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import checkpoint.six.model.Chamado;
import checkpoint.six.repository.ChamadoRepository;

import java.util.List;
import java.util.Optional;

@Service
public class ChamadoService {

@Autowired
private ChamadoRepository chamadoRepository;

public List<Chamado> listarTodosChamados() {
	return chamadoRepository.findAll();
	}
public Optional<Chamado> encontrarChamadoPorId(Long id) {
	 return chamadoRepository.findById(id);
}

public Chamado adicionarChamado(Chamado chamado) {
	 return chamadoRepository.save(chamado);
}

public void deletarChamado(Chamado chamado) {
	 chamadoRepository.delete(chamado);
}
public Chamado atualizarChamado(Chamado chamado) {
	  return chamadoRepository.save(chamado);
}
	}


