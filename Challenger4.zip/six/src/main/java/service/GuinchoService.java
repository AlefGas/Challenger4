package service;

import checkpoint.six.model.Guincho;
import checkpoint.six.repository.GuinchoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
@Service
public class GuinchoService {
    @Autowired
    private GuinchoRepository guinchoRepository;

    public List<Guincho> listarTodosGuinchos() {
        return guinchoRepository.findAll();
    }

    public Optional<Guincho> encontrarGuinchoPorId(String id) {
        return guinchoRepository.findById(id);
    }

    public Guincho adicionarGuincho(Guincho guincho) {
        return guinchoRepository.save(guincho);
    }

    public void deletarGuincho(Guincho guincho) {
        guinchoRepository.delete(guincho);
    }

    public Guincho atualizarGuincho(Guincho guincho) {
        return guinchoRepository.save(guincho);
    }
}

